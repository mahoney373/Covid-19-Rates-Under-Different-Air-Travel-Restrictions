library(knitr)
knitr::opts_chunk$set(echo = TRUE,message = FALSE,warning = FALSE)
library(tidyverse)
jhu_url <- paste("https://raw.githubusercontent.com/CSSEGISandData/", 
                 "COVID-19/master/csse_covid_19_data/",
                 "csse_covid_19_time_series/",
                 "time_series_covid19_confirmed_global.csv",sep="")

multi_confirmed_long_jhu <- read_csv(jhu_url) %>% 
  dplyr::rename(province = "Province/State", country_region = "Country/Region") %>%
  filter(country_region %in% c("Venezuela","Colombia","Brazil"))  %>%
  group_by(country_region) %>%
  pivot_longer(-c(province, country_region, Lat, Long), names_to = "Date", 
               values_to = "cumulative_cases") %>% 
  mutate(Date = lubridate::mdy(Date)) %>% 
  mutate(incident_cases = c(0, diff(cumulative_cases)))

# Adding the populations

popdf <- data.frame(country_region=c("Venezuela","Colombia","Brazil"),Population=c(28435940,50882891,212559417))

# Determining the total number of cases for each country from Jan. 1st 2021 to March 1st 2021

dfcompare <- dplyr::left_join(multi_confirmed_long_jhu,popdf, by="country_region") %>%
  mutate(incper100k=100000*(incident_cases/Population))
#Determining total person years
dfcompare1 <- dfcompare %>% filter(incident_cases > -1) %>% 
  filter((Date < lubridate::mdy("03/01/2021")) & (Date > lubridate::mdy("01/01/2021")))

statstable <- dfcompare1 %>%
  group_by(country_region) %>%
  dplyr::summarise(`Total Incident Cases` = sum(incident_cases),ndays=n()) 
statstable2 <- statstable %>% mutate(`Total Person Years`=ndays*c(212559417,50882891,28435940)/365)
statstable2

#BC <- as.table(matrix(c(2850681, 33776565, 596810, 8085500), nrow = 2, byrow = TRUE))
#BCval <- epiR::epi.2by2(dat = BC, method = "cohort.time", conf.level = 0.95, units = 1000,
                        #outcome = "as.columns")
#print(BCval)
#BV <- as.table(matrix(c(2850681, 33776565, 25232, 4518588), nrow = 2, byrow = TRUE))
#BVval <- epiR::epi.2by2(dat = BV, method = "cohort.time", conf.level = 0.95, units = 1000,
#                        outcome = "as.columns")
#print(BVval)

#CV <- as.table(matrix(c(596810, 8085500, 25232, 4518588), nrow = 2, byrow = TRUE))
#CVval <- epiR::epi.2by2(dat = CV, method = "cohort.time", conf.level = 0.95, units = 1000,
#                        outcome = "as.columns")
#print(CVval)
statstable1 <- multi_confirmed_long_jhu %>% filter(incident_cases > -1) %>% 
  filter(Date < lubridate::mdy("03/01/2021") & Date > lubridate::mdy("01/01/2021")) %>%
  group_by(country_region) %>%
  dplyr::summarise(`Average Number of Cases Per Day`= mean(incident_cases),
                   `SD of Daily Cases`= sd(incident_cases), `Cumulative Cases`= 
                     sum(incident_cases))